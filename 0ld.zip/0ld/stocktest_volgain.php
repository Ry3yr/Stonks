<?php
ini_set('memory_limit', '512M');
set_time_limit(0);

$ticker = $_GET['ticker'] ?? '';
if (!$ticker) {
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Volgain Test</title><style>body{font-family:monospace;margin:40px;background:#0f172a;color:#e2e8f0;}input{padding:10px;font-size:16px;width:200px;}button{padding:10px 20px;font-size:16px;cursor:pointer;}form{margin-bottom:30px;}.ok{color:#22c55e;}.fail{color:#ef4444;}.info{color:#94a3b8;}pre{background:#1e293b;padding:15px;border-radius:8px;overflow-x:auto;}table{border-collapse:collapse;width:100%;max-width:900px;margin-top:20px;}th,td{padding:6px 12px;text-align:right;border-bottom:1px solid #334155;}th{color:#94a3b8;text-align:left;}td.date{text-align:left;}.up{color:#22c55e;font-weight:bold;}.down{color:#ef4444;}.spike{color:#f59e0b;font-weight:bold;}.quiet{color:#64748b;}</style></head><body><h1>Volgain Algorithm Test</h1><form method="get"><input type="text" name="ticker" placeholder="e.g. AAPL" value=""><button type="submit">Test</button></form></body></html>';
    exit;
}

$ch = curl_init("https://query1.finance.yahoo.com/v8/finance/chart/{$ticker}?interval=1d&range=3wk");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false, CURLOPT_USERAGENT => 'Mozilla/5.0', CURLOPT_FOLLOWLOCATION => true
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode !== 200 || !$response) {
    die("Failed to fetch data for {$ticker} (HTTP {$httpCode})");
}

$data = json_decode($response, true);
$result = $data['chart']['result'][0] ?? null;
if (!$result) {
    $error = $data['chart']['error'] ?? 'Unknown error';
    die("Yahoo error for {$ticker}: " . json_encode($error));
}

$closes = $result['indicators']['quote'][0]['close'] ?? [];
$volumes = $result['indicators']['quote'][0]['volume'] ?? [];
$timestamps = $result['timestamp'] ?? [];

$prices = []; $vols = []; $dates = [];
foreach ($closes as $i => $c) {
    if (isset($c) && $c > 0) {
        $prices[] = $c;
        $vols[] = isset($volumes[$i]) ? (int)$volumes[$i] : 0;
        $dates[] = isset($timestamps[$i]) ? date('Y-m-d', $timestamps[$i]) : '?';
    }
}

$n = count($prices);

$report = [];
$report[] = "Ticker: {$ticker}";
$report[] = "Trading days in 3wk window: {$n}";
$report[] = "";

if ($n < 8) {
    $report[] = "RESULT: FAIL (need >= 8 days, got {$n})";
    $report[] = "REASON: Insufficient data.";
    output($report, $prices, $vols, $dates, false, [], 0, 0, 0);
    exit;
}

// === NEW ALGORITHM: Focus on spike and surrounding context ===

// Step 1: Find the last 5 days (the "action window")
$actionWindowSize = min(5, $n);
$actionStart = $n - $actionWindowSize;
$actionPrices = array_slice($prices, $actionStart);
$actionVols = array_slice($vols, $actionStart);
$actionDates = array_slice($dates, $actionStart);

// Step 2: Find the quiet period (everything before the action window)
$quietPrices = array_slice($prices, 0, $actionStart);
$quietVols = array_slice($vols, 0, $actionStart);

$quietAvgVol = count($quietVols) > 0 ? (array_sum($quietVols) / count($quietVols)) : 0;
$quietMinPrice = count($quietPrices) > 0 ? min($quietPrices) : 0;
$quietMaxPrice = count($quietPrices) > 0 ? max($quietPrices) : 0;

// Step 3: Find the SPIKE day(s) in the action window
// A spike day has volume >= 10x quiet average AND price up >= 20% from previous day
$spikeDays = [];
$spikeThresholdVol = $quietAvgVol * 10;
for ($i = 0; $i < count($actionVols); $i++) {
    $isVolSpike = $quietAvgVol > 0 && $actionVols[$i] >= $spikeThresholdVol;
    $isPriceJump = false;
    if ($i > 0) {
        $prevPrice = $actionPrices[$i-1];
        if ($prevPrice > 0) {
            $dayGain = (($actionPrices[$i] - $prevPrice) / $prevPrice) * 100;
            $isPriceJump = $dayGain >= 20;
        }
    } elseif ($actionStart > 0) {
        $prevPrice = $prices[$actionStart - 1];
        if ($prevPrice > 0) {
            $dayGain = (($actionPrices[$i] - $prevPrice) / $prevPrice) * 100;
            $isPriceJump = $dayGain >= 20;
        }
    }
    if ($isVolSpike && $isPriceJump) {
        $spikeDays[] = $i;
    }
}

// Step 4: If no spike-with-jump found, try just volume spike (>= 15x) even if price jump is smaller
if (empty($spikeDays)) {
    $spikeThresholdVolLoose = $quietAvgVol * 15;
    for ($i = 0; $i < count($actionVols); $i++) {
        $isVolSpike = $quietAvgVol > 0 && $actionVols[$i] >= $spikeThresholdVolLoose;
        $isPriceUp = false;
        if ($i > 0) {
            $isPriceUp = $actionPrices[$i] > $actionPrices[$i-1];
        } elseif ($actionStart > 0) {
            $isPriceUp = $actionPrices[$i] > $prices[$actionStart - 1];
        }
        if ($isVolSpike && $isPriceUp) {
            $spikeDays[] = $i;
        }
    }
}

// Step 5: Check continuation after spike
$hasContinuation = false;
$continuationGain = 0;
if (!empty($spikeDays)) {
    $lastSpikeIdx = $spikeDays[count($spikeDays) - 1];
    $spikePrice = $actionPrices[$lastSpikeIdx];
    $afterSpikePrices = array_slice($actionPrices, $lastSpikeIdx + 1);
    if (!empty($afterSpikePrices)) {
        $maxAfter = max($afterSpikePrices);
        $continuationGain = (($maxAfter - $spikePrice) / $spikePrice) * 100;
        $lastPrice = $actionPrices[count($actionPrices) - 1];
        $drawdown = (($spikePrice - $lastPrice) / $spikePrice) * 100;
        $hasContinuation = ($drawdown <= 20) || ($continuationGain > 0);
    } else {
        $hasContinuation = true;
    }
}

// Step 6: Calculate overall gain from quiet low to current
$currentPrice = $prices[$n - 1];
$totalGain = $quietMinPrice > 0 ? (($currentPrice - $quietMinPrice) / $quietMinPrice) * 100 : 0;

// Step 7: Is the spike recent? (within last 3 days)
$spikeIsRecent = false;
if (!empty($spikeDays)) {
    $lastSpikeIdx = $spikeDays[count($spikeDays) - 1];
    $spikeIsRecent = ($lastSpikeIdx >= count($actionPrices) - 3);
}

$report[] = "--- QUIET PERIOD (first " . count($quietPrices) . " days) ---";
$report[] = "  Avg volume: " . number_format($quietAvgVol, 0);
$report[] = "  Low price: " . number_format($quietMinPrice, 4);
$report[] = "  High price: " . number_format($quietMaxPrice, 4);
$report[] = "";
$report[] = "--- ACTION WINDOW (last {$actionWindowSize} days) ---";
$report[] = "  Spike days found: " . count($spikeDays);
for ($i = 0; $i < count($actionPrices); $i++) {
    $dayLabel = in_array($i, $spikeDays) ? 'SPIKE' : '';
    $volRatio = $quietAvgVol > 0 ? ($actionVols[$i] / $quietAvgVol) : 0;
    $volRatioStr = number_format($volRatio, 1);
    $report[] = "  " . $actionDates[$i] . ": Close=" . number_format($actionPrices[$i], 2) . " Vol=" . number_format($actionVols[$i], 0) . " (" . $volRatioStr . "x) " . $dayLabel;
}
$report[] = "";
$report[] = "--- METRICS ---";
$report[] = "  Total gain from quiet low: " . number_format($totalGain, 1) . "%";
$report[] = "  Spike volume threshold: " . number_format($spikeThresholdVol, 0) . " (10x quiet avg)";
$report[] = "  Spike found: " . (empty($spikeDays) ? 'NO' : 'YES');
$report[] = "  Spike is recent (last 3 days): " . ($spikeIsRecent ? 'YES' : 'NO');
$report[] = "  Has continuation: " . ($hasContinuation ? 'YES' : 'NO') . " (drawdown <= 20% or further gain)";
$report[] = "  Continuation gain after spike: " . number_format($continuationGain, 1) . "%";
$report[] = "";

$pass = true;
$reasons = [];

if (empty($spikeDays)) {
    $pass = false;
    $reasons[] = "No volume + price spike detected in the last {$actionWindowSize} days.";
} else {
    if (!$spikeIsRecent) {
        $pass = false;
        $reasons[] = "Spike happened too early (not in last 3 days) - may have already played out.";
    }
    if (!$hasContinuation) {
        $pass = false;
        $reasons[] = "Price crashed back down after spike (no continuation).";
    }
}
if ($totalGain < 30) {
    $pass = false;
    $reasons[] = "Total gain from low (" . number_format($totalGain, 1) . "%) is below 30% - move is too small.";
}

if ($pass) {
    $report[] = "RESULT: PASS";
    $report[] = "REASON: Recent volume spike with price jump, followed by continuation.";
} else {
    $report[] = "RESULT: FAIL";
    $report[] = "REASONS:";
    foreach ($reasons as $r) {
        $report[] = "  - " . $r;
    }
}

output($report, $prices, $vols, $dates, $pass, $spikeDays, $actionStart, $actionWindowSize, $quietAvgVol);

function output($report, $prices, $vols, $dates, $pass, $spikeDays, $actionStart, $actionWindowSize, $quietAvgVol) {
    $color = $pass ? '#22c55e' : '#ef4444';
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>Volgain Test</title><style>body{font-family:monospace;margin:40px;background:#0f172a;color:#e2e8f0;}input{padding:10px;font-size:16px;width:200px;}button{padding:10px 20px;font-size:16px;cursor:pointer;}form{margin-bottom:30px;}.ok{color:#22c55e;}.fail{color:#ef4444;}.info{color:#94a3b8;}pre{background:#1e293b;padding:15px;border-radius:8px;overflow-x:auto;}table{border-collapse:collapse;width:100%;max-width:900px;margin-top:20px;}th,td{padding:6px 12px;text-align:right;border-bottom:1px solid #334155;}th{color:#94a3b8;text-align:left;}td.date{text-align:left;}.up{color:#22c55e;font-weight:bold;}.down{color:#ef4444;}.spike{color:#f59e0b;font-weight:bold;}.quiet{color:#64748b;}</style></head><body>';
    echo '<h1>Volgain Algorithm Test</h1>';
    echo '<form method="get"><input type="text" name="ticker" placeholder="e.g. AAPL" value=""><button type="submit">Test</button></form>';
    echo '<pre style="border-left:4px solid ' . $color . ';">' . implode("\n", $report) . '</pre>';

    echo '<h3 class="info">Daily breakdown:</h3>';
    echo '<table><tr><th>Date</th><th>Close</th><th>Volume</th><th>Note</th></tr>';
    foreach ($prices as $i => $p) {
        $isAction = ($i >= $actionStart);
        $actionIdx = $i - $actionStart;
        $isSpike = $isAction && in_array($actionIdx, $spikeDays);
        $volRatio = $quietAvgVol > 0 ? ($vols[$i] / $quietAvgVol) : 0;

        if ($isSpike) {
            $note = '<span class="spike">SPIKE</span>';
        } elseif ($isAction && $volRatio >= 2) {
            $note = '<span class="up">elevated</span>';
        } elseif ($isAction) {
            $note = 'action';
        } else {
            $note = '<span class="quiet">quiet</span>';
        }

        $volClass = '';
        if ($isSpike) $volClass = 'spike';
        elseif ($isAction && $volRatio >= 2) $volClass = 'up';

        $priceClass = '';
        if ($i > 0) {
            $pct = (($p - $prices[$i-1]) / $prices[$i-1]) * 100;
            if ($pct >= 20) $priceClass = 'up';
            elseif ($pct <= -20) $priceClass = 'down';
        }

        echo '<tr><td class="date">' . $dates[$i] . '</td><td class="' . $priceClass . '">' . number_format($p, 2) . '</td><td class="' . $volClass . '">' . number_format($vols[$i], 0) . '</td><td>' . $note . '</td></tr>';
    }
    echo '</table></body></html>';
}
?>